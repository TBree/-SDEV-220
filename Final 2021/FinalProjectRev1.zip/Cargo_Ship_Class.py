'''
Name       : Do Not Sink My Cargo Ship Game
Author     : Torri Baptista
Version    : 1.0
Due Date   : 12/13/2021
Filename   :
'''
import torri_Library1 as Lib1
from Baptista_Linked_List import LinkedList
import random

class CargoShip:
    def __init__(self, inFileName):
        self.fileName = inFileName
        self.letters = ""
        self.guesses = ""
        self.misses= ""
        self.hiddenWord = ""
        self.displayWord = ""
        self.status = ""
        #
        self.flagEnd = False
        self.flagSink = False
        #
        self.listWords = []
        self.listCrates = ["","","","","","",""]
        #
        #=================================================================
        self.hiddenWord = "time"
        self.displayWord = "time"
        self.letters = "abcdefghijklmnopqrstuvwxyz"
        self.status = "Great, you won! "
        self.flagSink = False
        self.flagEnd = True
        #============================================================

        flagCheck = self.readFileName()
        if flagCheck == True:
            print(self.listWords)
            self.game()
        
        
    def printPanel(self):
        strGS = self.status
        strDW = self.displayWord
        lblGS = "game status  :"
        lblDW = "display word :"
        
        if self.flagEnd == True:
            strHW = self.hiddenWord
            lblHW = "hidden word  :"
        else:
            strHW = " "
            lblHW = "              "
            
        
        
        lblDD = "=============="
        strDD = "========================="
          
        #print("====================================================================================================")
        print(f'=={lblDD}={strDD:<20}====================================================')
        print(f'| {lblGS} {strGS:<20}    | avaliable letters : {self.letters}  ')
        print(f'| {lblHW} {strHW:<20}    | letters guessed   : {self.guesses} ')
        print(f'| {lblDW} {strDW:<20}    | incorrect letters : {self.misses} ')
        print(f'=={lblDD}={strDD:<20}====================================================')
        #print("====================================================================================================")
        
    def printDisplay(self):

        self.printPanel()
        Lib1.twoBlankLines()
        self.printCrate()
        self.printShip()

    def printCrate(self):
        print(f'          ********** [6] **********')
        print(f'          ********** [5] **********')
        print(f'          ********** [4] **********')
        print(f'          ********** [3] **********')
        print(f'          ********** [2] **********')
        print(f'          ********** [1] **********')
        print(f'          ********** [0] **********')
        
    def printShip(self):
        
        myName = "Cargo of the Sea"
        blanks = " "
        if self.flagSink == True:
            ifSink = "Your ship is sinking!"
        else:
            ifSink = " "
        
        print(f'    \- -- --- --- --- --- --- -- --- -- -/')
        print(f'     \      {ifSink:^21}       /')
        print(f'      \     {blanks:^21}      /')
        print(f'       \    {blanks:^21}     /')
        print(f'        \   {myName:^21}    /')
        print(f'         \  {blanks:^21}   /')
        print(f'     \-----------------------------------/')
        
    def game(self):

        self.getHiddenWord()
        self.replaceChar("a", 3) 
        self.printDisplay()
    

    def getHiddenWord(self):
        lenList = len(self.listWords)
        index1 = random.randrange(lenList) 
        self.hiddenWord = self.listWords[index1]
        lenWord = len(self.hiddenWord)
        if lenWord == 4:
            self.displayWord = "****"
        elif lenWord == 5:
            self.displayWord = "*****"
        elif lenWord == 6:
            self.displayWord = "******"

    def replaceChar(self, inChar, inIndex):
        temp1 = self.displayWord
        len1 = len(temp1)
        
        if inIndex == 0:
            self.displayWord = inChar + temp1[1:]
        elif inIndex == (len1 - 1):
            self.displayWord = temp1[:-1] + inChar
        else:
            plus1 = inIndex + 1
            minus1 = inIndex - 1
            self.displayWord = temp1[:minus1] + inChar + temp1[plus1:]
        
    def checkWord(self):
        pass
  
    def printErrorMsg(self, inErrorMsg):

        Lib1.twoBlankLines()
        print(inErrorMsg)
        Lib1.twoBlankLines()
        
    def readFileName(self):
        list1 = []
        flagOk = False
        self.listWords = []
        
        try:
            inFile = open(self.fileName,"r")
            list1 = inFile.readlines()
            inFile.close()
            #
        except:
            errMsg = f' Error - There was trouble opening your file. '
            self.printErrorMsg(errMsg)

        else:
            
            for line1 in list1:
                str1 = line1.strip() # gets rid of whitespace
                if str1.isalpha() == True and len(str1) >= 4 and len(str1) <= 6:
                    self.listWords.append(str1)
                    flagOk = True
                #__end_if
            #__for__
                
        finally:
            return flagOk





            
   
