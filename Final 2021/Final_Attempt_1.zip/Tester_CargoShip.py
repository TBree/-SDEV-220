
from Cargo_Ship_Class import CargoShip

# ======================================== #


myShip = CargoShip()


myShip.board()
myShip.game()


