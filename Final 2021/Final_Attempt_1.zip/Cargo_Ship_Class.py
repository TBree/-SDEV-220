'''
Name       : Do Not Sink My Cargo Ship Game
Author     : Torri Baptista
Version    : 1.0
Due Date   : 12/13/2021
Filename   :
'''
import torri_Library1 as Lib1
from Baptista_Linked_List import LinkedList

class CargoShip:
        
       
    def board (self):
        Lib1.printHeader(__doc__)
        
        
        print("==================================================================")
        print(f'| game status  :                      | avaliable letters :   ')
        print(f'| hidden word  :                      | letters guessed   :   ')
        print(f'| display word :                      | incorrect letters :   ')
        print("==================================================================")
        
        Lib1.twoBlankLines()
        print(f'          ********** [6] **********')
        print(f'          ********** [5] **********')
        print(f'          ********** [4] **********')
        print(f'          ********** [3] **********')
        print(f'          ********** [2] **********')
        print(f'          ********** [1] **********')
        print(f'          ********** [0] **********')
        

        myName = "Cargo of the Sea"
        blanks = " "
        ifSink = "Lets Play:Can You Win"

        print(f'    \- -- --- --- --- --- --- -- --- -- -/')
        print(f'     \      {ifSink:^21}       /')
        print(f'      \     {blanks:^21}      /')
        print(f'       \    {blanks:^21}     /')
        print(f'        \   {myName:^21}    /')
        print(f'         \  {blanks:^21}   /')
        print(f'     \-----------------------------------/')

    def game(self):
        
        letters = "abcdefghijklmnopqrstuvwxyz"
        letterList = []
        letterList = list(letters)

        print(f'Alphabet List:')
        print(f' |', *letterList, sep= '|')
        print()
        
        missesLetters = "bcefgjkmnpqrstuvwxz"
        missesList = []
        missesList = list(missesLetters)
        
        notInWord = []
        listGuessed = LinkedList()
#=========================================================#
        hiddenWord = tuple("holiday")
        hiddenWordList = []
        hiddenWordList = list(hiddenWord)
        
   
        
        for guesses in range(4): # goe 0-5:
            print()

            guesses = input("Make a guess between a-z:  (Type your answers in lowercase, 0 to quit):  ")
                
            if guesses == "":
                print(f'\nYour input value was {guesses}')
                print(f'Your string is empty.\n')
                print(f'You will remain in this loop until a valid string is entered. \n')

            elif guesses not in letters:
                print(f'\nYour input value was {guesses}')
                print(f'Your string has an invalid character. Input a lowercase letter between a-z. ')
                print(f'You will remain in this loop until a valid string is entered. \n')
            
            elif guesses in listGuessed:
                print(f'\nYour input value --> " {guesses} " <--  has already been used')
                print(f'You need to enter a new letter.\n')
                print(f'You will remain in this loop until a valid string is entered. \n')
                
 #=============  ================== ==============  =====================#            
            else:
                
                listGuessed.add(guesses) # adds the letter to a Letters Guessed list
                # print(f' Letters: ',listGuessed)

    
                print(f'\nMisses List:')
                print(f' |', *missesList, sep= ',')


       # missesLetters = "bcefgjkmnpqrstuvwxz"
       # missesList = []
       # missesList = list(missesLetters)
        
            if guesses in missesLetters:
                    print()
                    print(f'\nYou got --> {guesses} <-- wrong')
                    newMissesList = list(missesLetters)
                    
                    #print(f' So far you have guessed: {ListGuessed} ')
                        
                    print(f'\n|Incorrect Letters Guessed = {guesses}', sep=",")
                    print(f'|Letters Guessed:  {listGuessed}', sep=",")

                    # print(*ListMissed, sep=",")
                    newMissesList = missesLetters.replace(guesses, '')
                    print(f'\nAvaliable Letters:')
                    print(f'|',newMissesList, sep=",")

         
        if guesses == hiddenWord:
            print("Game Status: You won!")
        else:
            print('You Loose.  Would you like to play again? (y or n)')
   
   
       
   #================ ======================= ==========================



   
